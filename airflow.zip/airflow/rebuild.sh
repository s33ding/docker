bash destroy.sh
bash build.sh
