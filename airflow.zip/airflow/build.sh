NAME="airflow"
IMG="img-$NAME"

docker build . -t $IMG
