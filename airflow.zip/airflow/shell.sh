NAME="airflow"
docker start $NAME 
docker exec -it $NAME bash
